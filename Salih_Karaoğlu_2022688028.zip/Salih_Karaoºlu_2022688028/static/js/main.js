// yorum satırı
/* 
  Çoklu yorum satırı
*/
console.warn("Adınızın baş harfi küçük");
console.error("Kullanıcı adınız hatalı");
